package com.skillgap;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Core analysis engine for the Skill Gap Analyser.
 * Contains job role definitions, skill mappings, and analysis logic.
 */
public class SkillGapAnalyzer {

    // ─── Job Role Data Store ──────────────────────────────────────────────
    private static final Map<String, JobRole> JOB_ROLES = new LinkedHashMap<>();

    static {
        // ── Software Development ──
        JOB_ROLES.put("Frontend Developer", new JobRole(
            "Frontend Developer",
            "Software Development",
            Arrays.asList("HTML5", "CSS3", "JavaScript", "React.js", "Vue.js or Angular", "TypeScript", "Responsive Design", "Git", "REST APIs", "Webpack/Vite", "UI/UX Principles", "Testing (Jest/Cypress)"),
            Arrays.asList(
                new LearningResource("HTML & CSS Mastery", "https://developer.mozilla.org/en-US/docs/Learn", "Free", "Beginner"),
                new LearningResource("JavaScript - The Complete Guide", "https://javascript.info", "Free", "Beginner"),
                new LearningResource("React Official Tutorial", "https://react.dev/learn", "Free", "Intermediate"),
                new LearningResource("TypeScript Handbook", "https://www.typescriptlang.org/docs/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹4,00,000 - ₹12,00,000 per year"
        ));

        JOB_ROLES.put("Backend Developer", new JobRole(
            "Backend Developer",
            "Software Development",
            Arrays.asList("Java", "Python or Node.js", "SQL Databases", "NoSQL Databases", "REST API Design", "Microservices", "Docker", "Git", "Linux/Unix", "Security Best Practices", "Cloud Services (AWS/GCP/Azure)", "Message Queues"),
            Arrays.asList(
                new LearningResource("Java Programming Masterclass", "https://dev.java/learn/", "Free", "Beginner"),
                new LearningResource("Database Design & SQL", "https://www.w3schools.com/sql/", "Free", "Beginner"),
                new LearningResource("Docker Getting Started", "https://docs.docker.com/get-started/", "Free", "Intermediate"),
                new LearningResource("AWS Cloud Practitioner", "https://aws.amazon.com/training/", "Paid", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹5,00,000 - ₹18,00,000 per year"
        ));

        JOB_ROLES.put("Full Stack Developer", new JobRole(
            "Full Stack Developer",
            "Software Development",
            Arrays.asList("HTML5", "CSS3", "JavaScript", "React.js or Angular", "Node.js or Java", "SQL & NoSQL Databases", "REST APIs", "Git", "Docker", "Cloud Services", "CI/CD Pipelines", "TypeScript", "Testing Frameworks"),
            Arrays.asList(
                new LearningResource("The Odin Project", "https://www.theodinproject.com/", "Free", "Beginner"),
                new LearningResource("Full Stack Open", "https://fullstackopen.com/en/", "Free", "Intermediate"),
                new LearningResource("Docker & Kubernetes", "https://docs.docker.com/", "Free", "Advanced"),
                new LearningResource("System Design Primer", "https://github.com/donnemartin/system-design-primer", "Free", "Advanced")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹6,00,000 - ₹20,00,000 per year"
        ));

        JOB_ROLES.put("Mobile App Developer", new JobRole(
            "Mobile App Developer",
            "Software Development",
            Arrays.asList("Kotlin/Swift", "React Native or Flutter", "Mobile UI Design", "REST APIs", "SQLite/Realm", "Push Notifications", "App Store Deployment", "Git", "Firebase", "Performance Optimization", "Offline Storage", "Testing"),
            Arrays.asList(
                new LearningResource("Android Development with Kotlin", "https://developer.android.com/courses", "Free", "Beginner"),
                new LearningResource("Flutter Complete Guide", "https://flutter.dev/docs", "Free", "Beginner"),
                new LearningResource("iOS Development with Swift", "https://developer.apple.com/tutorials/", "Free", "Intermediate"),
                new LearningResource("Firebase Documentation", "https://firebase.google.com/docs", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹4,00,000 - ₹16,00,000 per year"
        ));

        JOB_ROLES.put("DevOps Engineer", new JobRole(
            "DevOps Engineer",
            "Software Development",
            Arrays.asList("Linux Administration", "Docker", "Kubernetes", "CI/CD (Jenkins/GitHub Actions)", "AWS/GCP/Azure", "Terraform/Ansible", "Monitoring (Prometheus/Grafana)", "Scripting (Bash/Python)", "Networking", "Security", "Git", "Infrastructure as Code"),
            Arrays.asList(
                new LearningResource("Linux Administration", "https://linuxjourney.com/", "Free", "Beginner"),
                new LearningResource("Docker Deep Dive", "https://docs.docker.com/", "Free", "Intermediate"),
                new LearningResource("Kubernetes Documentation", "https://kubernetes.io/docs/", "Free", "Intermediate"),
                new LearningResource("AWS Solutions Architect", "https://aws.amazon.com/certification/", "Paid", "Advanced")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹6,00,000 - ₹22,00,000 per year"
        ));

        // ── Data & AI ──
        JOB_ROLES.put("Data Scientist", new JobRole(
            "Data Scientist",
            "Data & AI",
            Arrays.asList("Python", "R Programming", "Statistics & Probability", "Machine Learning", "Deep Learning", "SQL", "Data Visualization (Matplotlib/Tableau)", "Pandas/NumPy", "TensorFlow/PyTorch", "Feature Engineering", "A/B Testing", "Big Data (Spark)"),
            Arrays.asList(
                new LearningResource("Python for Data Science", "https://www.kaggle.com/learn", "Free", "Beginner"),
                new LearningResource("Statistics & Probability", "https://www.khanacademy.org/math/statistics-probability", "Free", "Beginner"),
                new LearningResource("Machine Learning by Andrew Ng", "https://www.coursera.org/learn/machine-learning", "Free", "Intermediate"),
                new LearningResource("Deep Learning Specialization", "https://www.deeplearning.ai/", "Paid", "Advanced")
            ),
            "Master's/PhD in CS, Statistics, Mathematics or related",
            "₹6,00,000 - ₹25,00,000 per year"
        ));

        JOB_ROLES.put("Data Analyst", new JobRole(
            "Data Analyst",
            "Data & AI",
            Arrays.asList("SQL", "Excel Advanced", "Python or R", "Data Visualization (Tableau/Power BI)", "Statistics", "Data Cleaning", "Business Intelligence", "ETL Processes", "Critical Thinking", "Communication Skills", "Dashboard Design"),
            Arrays.asList(
                new LearningResource("SQL for Data Analysis", "https://mode.com/sql-tutorial/", "Free", "Beginner"),
                new LearningResource("Excel Skills for Business", "https://www.coursera.org/specializations/excel", "Free", "Beginner"),
                new LearningResource("Tableau Training", "https://www.tableau.com/learn/training", "Free", "Intermediate"),
                new LearningResource("Google Data Analytics Certificate", "https://www.coursera.org/professional-certificates/google-data-analytics", "Paid", "Beginner")
            ),
            "Bachelor's in any analytical field",
            "₹4,00,000 - ₹12,00,000 per year"
        ));

        JOB_ROLES.put("ML Engineer", new JobRole(
            "ML Engineer",
            "Data & AI",
            Arrays.asList("Python", "Machine Learning Algorithms", "Deep Learning (TensorFlow/PyTorch)", "MLOps", "Docker", "Cloud ML Services", "Data Pipelines", "Model Deployment", "SQL", "Git", "Linux", "Mathematics (Linear Algebra, Calculus)"),
            Arrays.asList(
                new LearningResource("Fast.ai Practical Deep Learning", "https://course.fast.ai/", "Free", "Intermediate"),
                new LearningResource("MLOps Specialization", "https://www.deeplearning.ai/courses/machine-learning-engineering-for-production-mlops/", "Paid", "Advanced"),
                new LearningResource("Mathematics for ML", "https://mml-book.github.io/", "Free", "Intermediate"),
                new LearningResource("Kaggle Competitions", "https://www.kaggle.com/competitions", "Free", "Intermediate")
            ),
            "Master's in CS/ML or equivalent experience",
            "₹8,00,000 - ₹30,00,000 per year"
        ));

        JOB_ROLES.put("AI Engineer", new JobRole(
            "AI Engineer",
            "Data & AI",
            Arrays.asList("Python", "Deep Learning", "Natural Language Processing", "Computer Vision", "LLMs & Prompt Engineering", "TensorFlow/PyTorch", "Cloud AI Services", "MLOps", "Docker", "API Development", "Mathematics", "Research Paper Reading"),
            Arrays.asList(
                new LearningResource("Deep Learning Specialization", "https://www.deeplearning.ai/", "Paid", "Intermediate"),
                new LearningResource("Hugging Face NLP Course", "https://huggingface.co/learn/nlp-course", "Free", "Intermediate"),
                new LearningResource("Stanford CS231n (Computer Vision)", "http://cs231n.stanford.edu/", "Free", "Advanced"),
                new LearningResource("LangChain Documentation", "https://docs.langchain.com/", "Free", "Intermediate")
            ),
            "Master's/PhD in CS, AI or related field",
            "₹8,00,000 - ₹32,00,000 per year"
        ));

        // ── Cybersecurity ──
        JOB_ROLES.put("Cybersecurity Analyst", new JobRole(
            "Cybersecurity Analyst",
            "Cybersecurity",
            Arrays.asList("Network Security", "SIEM Tools", "Vulnerability Assessment", "Incident Response", "Firewalls & IDS/IPS", "Linux/Windows Administration", "Python Scripting", "Risk Assessment", "Compliance (GDPR/HIPAA)", "Encryption", "Threat Intelligence", "Security Frameworks (NIST)"),
            Arrays.asList(
                new LearningResource("CompTIA Security+", "https://www.comptia.org/certifications/security", "Paid", "Beginner"),
                new LearningResource("TryHackMe Learning Paths", "https://tryhackme.com/", "Free/Paid", "Beginner"),
                new LearningResource("Cybersecurity Fundamentals", "https://www.sans.org/cyber-security-courses/", "Paid", "Intermediate"),
                new LearningResource("CEH Certification", "https://www.eccouncil.org/programs/certified-ethical-hacker-ceh/", "Paid", "Intermediate")
            ),
            "Bachelor's in CS/IT/Cybersecurity",
            "₹4,00,000 - ₹15,00,000 per year"
        ));

        JOB_ROLES.put("Ethical Hacker", new JobRole(
            "Ethical Hacker",
            "Cybersecurity",
            Arrays.asList("Penetration Testing", "Web Application Security", "Network Security", "Kali Linux", "Metasploit", "Burp Suite", "Python/Bash Scripting", "OWASP Top 10", "Social Engineering", "Wireless Security", "Reverse Engineering", "Report Writing"),
            Arrays.asList(
                new LearningResource("Hack The Box Academy", "https://academy.hackthebox.com/", "Free/Paid", "Beginner"),
                new LearningResource("OSCP Certification", "https://www.offsec.com/courses/pen-200/", "Paid", "Advanced"),
                new LearningResource("PortSwigger Web Security Academy", "https://portswigger.net/web-security", "Free", "Intermediate"),
                new LearningResource("PentesterLab", "https://pentesterlab.com/", "Paid", "Intermediate")
            ),
            "Bachelor's in CS/IT/Cybersecurity",
            "₹5,00,000 - ₹18,00,000 per year"
        ));

        // ── Design ──
        JOB_ROLES.put("UI/UX Designer", new JobRole(
            "UI/UX Designer",
            "Design",
            Arrays.asList("Figma", "Adobe XD", "User Research", "Wireframing", "Prototyping", "Design Systems", "Typography", "Color Theory", "Usability Testing", "Responsive Design", "Accessibility (WCAG)", "Interaction Design"),
            Arrays.asList(
                new LearningResource("Google UX Design Certificate", "https://www.coursera.org/professional-certificates/google-ux-design", "Paid", "Beginner"),
                new LearningResource("Figma Official Tutorials", "https://www.figma.com/resources/learn-design/", "Free", "Beginner"),
                new LearningResource("Laws of UX", "https://lawsofux.com/", "Free", "Intermediate"),
                new LearningResource("Nielsen Norman Group Articles", "https://www.nngroup.com/articles/", "Free", "Intermediate")
            ),
            "Bachelor's in Design, HCI, or related field",
            "₹4,00,000 - ₹14,00,000 per year"
        ));

        JOB_ROLES.put("Graphic Designer", new JobRole(
            "Graphic Designer",
            "Design",
            Arrays.asList("Adobe Photoshop", "Adobe Illustrator", "Typography", "Color Theory", "Layout Design", "Brand Identity", "Print Design", "Digital Design", "Motion Graphics (After Effects)", "Adobe InDesign", "Creative Thinking", "Communication Skills"),
            Arrays.asList(
                new LearningResource("Adobe Creative Cloud Tutorials", "https://helpx.adobe.com/creative-cloud/tutorials-explore.html", "Free", "Beginner"),
                new LearningResource("Canva Design School", "https://www.canva.com/designschool/", "Free", "Beginner"),
                new LearningResource("Typography Fundamentals", "https://practicaltypography.com/", "Free", "Beginner"),
                new LearningResource("Skillshare Design Classes", "https://www.skillshare.com/", "Paid", "Intermediate")
            ),
            "Bachelor's in Graphic Design or related field",
            "₹3,00,000 - ₹10,00,000 per year"
        ));

        // ── Cloud & Infrastructure ──
        JOB_ROLES.put("Cloud Architect", new JobRole(
            "Cloud Architect",
            "Cloud & Infrastructure",
            Arrays.asList("AWS/Azure/GCP", "Infrastructure as Code (Terraform)", "Networking (VPC, DNS, Load Balancers)", "Security & IAM", "Containerization (Docker/Kubernetes)", "Serverless Architecture", "Cost Optimization", "High Availability Design", "Monitoring & Logging", "Database Services", "CI/CD Pipelines", "Disaster Recovery"),
            Arrays.asList(
                new LearningResource("AWS Solutions Architect Associate", "https://aws.amazon.com/certification/certified-solutions-architect-associate/", "Paid", "Intermediate"),
                new LearningResource("Google Cloud Architect", "https://cloud.google.com/certification/cloud-architect", "Paid", "Advanced"),
                new LearningResource("Terraform Documentation", "https://developer.hashicorp.com/terraform/docs", "Free", "Intermediate"),
                new LearningResource("Cloud Design Patterns", "https://docs.microsoft.com/en-us/azure/architecture/patterns/", "Free", "Advanced")
            ),
            "Bachelor's in CS/IT with cloud certifications",
            "₹12,00,000 - ₹40,00,000 per year"
        ));

        // ── Product & Management ──
        JOB_ROLES.put("Product Manager", new JobRole(
            "Product Manager",
            "Product & Management",
            Arrays.asList("Product Strategy", "User Research", "Data Analysis", "Agile/Scrum", "Roadmap Planning", "Stakeholder Management", "A/B Testing", "Market Analysis", "SQL Basics", "Wireframing", "Communication Skills", "Leadership"),
            Arrays.asList(
                new LearningResource("Product Management Course", "https://www.productschool.com/", "Paid", "Beginner"),
                new LearningResource("Inspired by Marty Cagan", "https://www.svpg.com/inspired-how-to-create-products-customers-love/", "Paid", "Intermediate"),
                new LearningResource("Agile & Scrum Fundamentals", "https://www.scrum.org/resources", "Free", "Beginner"),
                new LearningResource("Google Analytics Academy", "https://analytics.google.com/analytics/academy/", "Free", "Beginner")
            ),
            "Bachelor's in Business, CS, or related field + experience",
            "₹8,00,000 - ₹30,00,000 per year"
        ));

        JOB_ROLES.put("Project Manager", new JobRole(
            "Project Manager",
            "Product & Management",
            Arrays.asList("Project Planning", "Agile/Scrum/Kanban", "Risk Management", "Budgeting", "Stakeholder Communication", "JIRA/Trello", "MS Project", "Team Leadership", "Conflict Resolution", "Documentation", "PMP Certification Knowledge", "Time Management"),
            Arrays.asList(
                new LearningResource("PMP Certification Prep", "https://www.pmi.org/certifications/project-management-pmp", "Paid", "Intermediate"),
                new LearningResource("Google Project Management Certificate", "https://www.coursera.org/professional-certificates/google-project-management", "Paid", "Beginner"),
                new LearningResource("Scrum Master Certification", "https://www.scrum.org/assessments/professional-scrum-master-i-certification", "Paid", "Intermediate"),
                new LearningResource("Atlassian Agile Coach", "https://www.atlassian.com/agile", "Free", "Beginner")
            ),
            "Bachelor's in any field + PMP preferred",
            "₹5,00,000 - ₹18,00,000 per year"
        ));

        // ── Digital Marketing ──
        JOB_ROLES.put("Digital Marketing Specialist", new JobRole(
            "Digital Marketing Specialist",
            "Digital Marketing",
            Arrays.asList("SEO/SEM", "Google Analytics", "Social Media Marketing", "Content Marketing", "Email Marketing", "PPC Advertising", "Google Ads", "Facebook/Meta Ads", "Copywriting", "Marketing Automation", "CRM Tools", "Data Analysis"),
            Arrays.asList(
                new LearningResource("Google Digital Marketing Certificate", "https://skillshop.withgoogle.com/", "Free", "Beginner"),
                new LearningResource("HubSpot Academy", "https://academy.hubspot.com/", "Free", "Beginner"),
                new LearningResource("SEO Learning Center (Moz)", "https://moz.com/learn/seo", "Free", "Intermediate"),
                new LearningResource("Facebook Blueprint", "https://www.facebook.com/business/learn", "Free", "Intermediate")
            ),
            "Bachelor's in Marketing, Business, or related field",
            "₹3,00,000 - ₹12,00,000 per year"
        ));

        // ── Database ──
        JOB_ROLES.put("Database Administrator", new JobRole(
            "Database Administrator",
            "Cloud & Infrastructure",
            Arrays.asList("SQL (MySQL/PostgreSQL/Oracle)", "Database Design & Normalization", "Performance Tuning", "Backup & Recovery", "Replication & Clustering", "NoSQL (MongoDB/Redis)", "Security & Access Control", "Cloud Database Services", "ETL Processes", "Scripting (Bash/Python)", "Monitoring Tools", "High Availability"),
            Arrays.asList(
                new LearningResource("SQL & Database Fundamentals", "https://www.w3schools.com/sql/", "Free", "Beginner"),
                new LearningResource("PostgreSQL Documentation", "https://www.postgresql.org/docs/", "Free", "Intermediate"),
                new LearningResource("Oracle DBA Certification", "https://education.oracle.com/", "Paid", "Advanced"),
                new LearningResource("MongoDB University", "https://university.mongodb.com/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹5,00,000 - ₹18,00,000 per year"
        ));

        // ── QA / Testing ──
        JOB_ROLES.put("QA Engineer", new JobRole(
            "QA Engineer",
            "Software Development",
            Arrays.asList("Manual Testing", "Test Automation (Selenium/Cypress)", "API Testing (Postman/RestAssured)", "Performance Testing (JMeter)", "Test Planning & Strategy", "Bug Tracking (JIRA)", "SQL Basics", "Git", "CI/CD Understanding", "Agile/Scrum", "Python/Java Basics", "Security Testing Basics"),
            Arrays.asList(
                new LearningResource("ISTQB Foundation Level", "https://www.istqb.org/", "Paid", "Beginner"),
                new LearningResource("Selenium WebDriver Tutorial", "https://www.selenium.dev/documentation/", "Free", "Intermediate"),
                new LearningResource("Postman Learning Center", "https://learning.postman.com/", "Free", "Beginner"),
                new LearningResource("Test Automation University", "https://testautomationu.applitools.com/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹4,00,000 - ₹15,00,000 per year"
        ));

        // ── Blockchain ──
        JOB_ROLES.put("Blockchain Developer", new JobRole(
            "Blockchain Developer",
            "Emerging Technologies",
            Arrays.asList("Solidity", "Ethereum & Smart Contracts", "Web3.js/Ethers.js", "Cryptography Fundamentals", "Consensus Mechanisms", "DeFi Protocols", "Hardhat/Truffle", "IPFS", "Token Standards (ERC-20/721)", "Security Auditing", "JavaScript/TypeScript", "Rust (for Solana)"),
            Arrays.asList(
                new LearningResource("CryptoZombies", "https://cryptozombies.io/", "Free", "Beginner"),
                new LearningResource("Ethereum Developer Documentation", "https://ethereum.org/en/developers/", "Free", "Intermediate"),
                new LearningResource("Alchemy University", "https://university.alchemy.com/", "Free", "Intermediate"),
                new LearningResource("Solidity by Example", "https://solidity-by-example.org/", "Free", "Intermediate")
            ),
            "Bachelor's in CS/IT or equivalent",
            "₹8,00,000 - ₹30,00,000 per year"
        ));

        // ── Engineering disciplines ──
        JOB_ROLES.put("Mechanical Design Engineer", engineeringRole(
            "Mechanical Design Engineer", "Mechanical Engineering",
            Arrays.asList("Engineering Mechanics", "Machine Design", "CAD (SolidWorks/Creo)", "Materials Science", "GD&T", "Thermodynamics", "Manufacturing Processes", "Finite Element Analysis", "Technical Drawings", "Project Planning"),
            "B.E./B.Tech in Mechanical Engineering or equivalent", "₹3,00,000 - ₹12,00,000 per year",
            new LearningResource("NPTEL Mechanical Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Engineering Mechanics", "Machine Design", "Materials Science", "Thermodynamics", "Manufacturing Processes")),
            new LearningResource("SOLIDWORKS Tutorials", "https://my.solidworks.com/training", "Free", "Beginner", Arrays.asList("CAD (SolidWorks/Creo)", "GD&T", "Technical Drawings")),
            new LearningResource("MIT OpenCourseWare: Mechanical Engineering", "https://ocw.mit.edu/search/?d=Mechanical%20Engineering", "Free", "Intermediate", Arrays.asList("Finite Element Analysis", "Machine Design", "Project Planning"))
        ));

        JOB_ROLES.put("Electrical Engineer", engineeringRole(
            "Electrical Engineer", "Electrical Engineering",
            Arrays.asList("Circuit Analysis", "Electrical Machines", "Power Systems", "Control Systems", "Power Electronics", "MATLAB/Simulink", "Electrical Safety", "PLC/SCADA", "Electrical CAD", "Renewable Energy Systems"),
            "B.E./B.Tech in Electrical Engineering or equivalent", "₹3,00,000 - ₹12,00,000 per year",
            new LearningResource("NPTEL Electrical Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Circuit Analysis", "Electrical Machines", "Power Systems", "Control Systems", "Renewable Energy Systems")),
            new LearningResource("MATLAB and Simulink Onramp", "https://matlabacademy.mathworks.com/", "Free", "Beginner", Arrays.asList("MATLAB/Simulink", "Control Systems")),
            new LearningResource("Schneider Electric University", "https://www.se.com/ww/en/about-us/university/", "Free", "Intermediate", Arrays.asList("Power Electronics", "PLC/SCADA", "Electrical Safety")),
            new LearningResource("Autodesk Electrical Design Resources", "https://www.autodesk.com/solutions/electrical-design-software", "Free", "Beginner", Arrays.asList("Electrical CAD"))
        ));

        JOB_ROLES.put("Civil Engineer", engineeringRole(
            "Civil Engineer", "Civil Engineering",
            Arrays.asList("Structural Analysis", "AutoCAD", "Building Information Modeling (Revit)", "Concrete and Steel Design", "Geotechnical Engineering", "Surveying", "Construction Management", "Estimation and Costing", "Building Codes", "Project Scheduling"),
            "B.E./B.Tech in Civil Engineering or equivalent", "₹3,00,000 - ₹12,00,000 per year",
            new LearningResource("NPTEL Civil Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Structural Analysis", "Concrete and Steel Design", "Geotechnical Engineering", "Surveying")),
            new LearningResource("Autodesk Revit Learning", "https://www.autodesk.com/learn/ondemand/collection/revit", "Free", "Beginner", Arrays.asList("Building Information Modeling (Revit)", "AutoCAD")),
            new LearningResource("Autodesk Construction Cloud Learning", "https://learn.acc.autodesk.com/", "Free", "Intermediate", Arrays.asList("Construction Management", "Estimation and Costing", "Project Scheduling")),
            new LearningResource("Bureau of Indian Standards", "https://www.bis.gov.in/", "Free", "Intermediate", Arrays.asList("Building Codes"))
        ));

        JOB_ROLES.put("Chemical Process Engineer", engineeringRole(
            "Chemical Process Engineer", "Chemical Engineering",
            Arrays.asList("Mass and Energy Balances", "Chemical Reaction Engineering", "Transport Phenomena", "Process Design", "Process Simulation (Aspen Plus)", "Process Control", "Process Safety (HAZOP)", "Plant Operations", "Thermodynamics", "Environmental Compliance"),
            "B.E./B.Tech in Chemical Engineering or equivalent", "₹4,00,000 - ₹14,00,000 per year",
            new LearningResource("NPTEL Chemical Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Mass and Energy Balances", "Chemical Reaction Engineering", "Transport Phenomena", "Process Control", "Thermodynamics")),
            new LearningResource("AspenTech Learning Center", "https://www.aspentech.com/en/knowledge/learning-center", "Free", "Intermediate", Arrays.asList("Process Simulation (Aspen Plus)", "Process Design")),
            new LearningResource("AIChE Center for Chemical Process Safety", "https://www.aiche.org/ccps", "Free", "Intermediate", Arrays.asList("Process Safety (HAZOP)", "Plant Operations", "Environmental Compliance"))
        ));

        JOB_ROLES.put("Aerospace Engineer", engineeringRole(
            "Aerospace Engineer", "Aerospace Engineering",
            Arrays.asList("Aerodynamics", "Flight Mechanics", "Aircraft Structures", "Propulsion Systems", "CAD/CAE (CATIA/ANSYS)", "Computational Fluid Dynamics", "Materials Science", "Control Systems", "Systems Engineering", "Safety and Certification"),
            "B.E./B.Tech in Aerospace or Aeronautical Engineering or equivalent", "₹5,00,000 - ₹18,00,000 per year",
            new LearningResource("NASA Aeronautics Research Learning Resources", "https://www.nasa.gov/learning-resources/", "Free", "Beginner", Arrays.asList("Aerodynamics", "Flight Mechanics", "Propulsion Systems")),
            new LearningResource("MIT OpenCourseWare: Aeronautics and Astronautics", "https://ocw.mit.edu/search/?d=Aeronautics%20and%20Astronautics", "Free", "Intermediate", Arrays.asList("Aircraft Structures", "Materials Science", "Control Systems", "Systems Engineering")),
            new LearningResource("Ansys Innovation Courses", "https://courses.ansys.com/", "Free", "Intermediate", Arrays.asList("CAD/CAE (CATIA/ANSYS)", "Computational Fluid Dynamics")),
            new LearningResource("FAA Aircraft Certification", "https://www.faa.gov/aircraft", "Free", "Intermediate", Arrays.asList("Safety and Certification"))
        ));

        JOB_ROLES.put("Biomedical Engineer", engineeringRole(
            "Biomedical Engineer", "Biomedical Engineering",
            Arrays.asList("Human Anatomy and Physiology", "Medical Instrumentation", "Biomaterials", "Medical Device Design", "Signal Processing", "Regulatory Standards (FDA/ISO 13485)", "Clinical Engineering", "MATLAB/Python", "Risk Management (ISO 14971)", "Quality Systems"),
            "B.E./B.Tech in Biomedical Engineering or related discipline", "₹3,50,000 - ₹12,00,000 per year",
            new LearningResource("NPTEL Biomedical Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Human Anatomy and Physiology", "Medical Instrumentation", "Biomaterials")),
            new LearningResource("FDA Medical Device Learning Resources", "https://www.fda.gov/medical-devices", "Free", "Intermediate", Arrays.asList("Medical Device Design", "Regulatory Standards (FDA/ISO 13485)", "Risk Management (ISO 14971)", "Quality Systems")),
            new LearningResource("MathWorks Biomedical Engineering Resources", "https://www.mathworks.com/solutions/biomedical-engineering.html", "Free", "Intermediate", Arrays.asList("Signal Processing", "MATLAB/Python")),
            new LearningResource("WHO Medical Device Resources", "https://www.who.int/health-topics/medical-devices", "Free", "Intermediate", Arrays.asList("Clinical Engineering"))
        ));

        JOB_ROLES.put("Industrial Engineer", engineeringRole(
            "Industrial Engineer", "Industrial Engineering",
            Arrays.asList("Operations Research", "Lean Manufacturing", "Six Sigma", "Supply Chain Management", "Production Planning", "Quality Engineering", "Ergonomics", "Statistical Process Control", "Simulation (Arena/AnyLogic)", "Cost Analysis"),
            "B.E./B.Tech in Industrial/Production Engineering or equivalent", "₹4,00,000 - ₹15,00,000 per year",
            new LearningResource("NPTEL Industrial Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Operations Research", "Production Planning", "Quality Engineering", "Ergonomics", "Simulation (Arena/AnyLogic)")),
            new LearningResource("ASQ Lean Six Sigma Resources", "https://asq.org/quality-resources/lean", "Free", "Intermediate", Arrays.asList("Lean Manufacturing", "Six Sigma", "Statistical Process Control")),
            new LearningResource("MIT OpenCourseWare: Supply Chain Management", "https://ocw.mit.edu/search/?q=supply%20chain", "Free", "Intermediate", Arrays.asList("Supply Chain Management", "Cost Analysis"))
        ));

        JOB_ROLES.put("Environmental Engineer", engineeringRole(
            "Environmental Engineer", "Environmental Engineering",
            Arrays.asList("Environmental Chemistry", "Water and Wastewater Treatment", "Air Pollution Control", "Solid Waste Management", "Environmental Impact Assessment", "GIS", "Environmental Regulations", "Sustainability", "Hydrology", "Sampling and Data Analysis"),
            "B.E./B.Tech in Environmental/Civil Engineering or equivalent", "₹3,00,000 - ₹12,00,000 per year",
            new LearningResource("NPTEL Environmental Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Environmental Chemistry", "Water and Wastewater Treatment", "Air Pollution Control")),
            new LearningResource("US EPA Learn the Basics", "https://www.epa.gov/environmental-topics", "Free", "Beginner", Arrays.asList("Solid Waste Management", "Environmental Regulations", "Sustainability", "Hydrology")),
            new LearningResource("QGIS Training Manual", "https://docs.qgis.org/latest/en/docs/training_manual/", "Free", "Intermediate", Arrays.asList("GIS", "Environmental Impact Assessment")),
            new LearningResource("EPA Measurements and Modeling Resources", "https://www.epa.gov/measurements-modeling", "Free", "Intermediate", Arrays.asList("Sampling and Data Analysis"))
        ));

        JOB_ROLES.put("Embedded Systems Engineer", engineeringRole(
            "Embedded Systems Engineer", "Electronics & Communication Engineering",
            Arrays.asList("Digital Electronics", "Microcontrollers (ARM/AVR)", "C/C++", "Embedded Linux", "RTOS", "PCB Design", "Communication Protocols (UART/SPI/I2C)", "Device Drivers", "Debugging (JTAG)", "Hardware-Software Integration"),
            "B.E./B.Tech in Electronics/Electrical Engineering or equivalent", "₹4,00,000 - ₹16,00,000 per year",
            new LearningResource("Arm Learning Paths", "https://learn.arm.com/", "Free", "Beginner", Arrays.asList("Microcontrollers (ARM/AVR)", "C/C++", "Digital Electronics", "Hardware-Software Integration")),
            new LearningResource("FreeRTOS Documentation", "https://www.freertos.org/Documentation/RTOS_book.html", "Free", "Intermediate", Arrays.asList("RTOS", "Communication Protocols (UART/SPI/I2C)")),
            new LearningResource("Linux Device Drivers Documentation", "https://docs.kernel.org/driver-api/", "Free", "Advanced", Arrays.asList("Embedded Linux", "Device Drivers", "Debugging (JTAG)")),
            new LearningResource("KiCad Documentation", "https://docs.kicad.org/", "Free", "Beginner", Arrays.asList("PCB Design"))
        ));

        JOB_ROLES.put("Robotics Engineer", engineeringRole(
            "Robotics Engineer", "Mechatronics & Robotics",
            Arrays.asList("Robot Kinematics", "Control Systems", "ROS 2", "C++/Python", "Sensors and Actuators", "Computer Vision", "Path Planning", "Embedded Systems", "CAD and Prototyping", "Machine Learning for Robotics"),
            "B.E./B.Tech in Robotics/Mechatronics/Electrical Engineering or equivalent", "₹5,00,000 - ₹18,00,000 per year",
            new LearningResource("ROS 2 Tutorials", "https://docs.ros.org/en/rolling/Tutorials.html", "Free", "Beginner", Arrays.asList("ROS 2", "C++/Python", "Robot Kinematics", "Embedded Systems")),
            new LearningResource("Modern Robotics (free textbook and videos)", "https://modernrobotics.northwestern.edu/", "Free", "Intermediate", Arrays.asList("Robot Kinematics", "Control Systems", "Path Planning")),
            new LearningResource("NVIDIA Isaac Sim Learning", "https://developer.nvidia.com/isaac/sim", "Free", "Intermediate", Arrays.asList("Computer Vision", "Sensors and Actuators", "Machine Learning for Robotics")),
            new LearningResource("Onshape Learning Center", "https://learn.onshape.com/", "Free", "Beginner", Arrays.asList("CAD and Prototyping"))
        ));

        JOB_ROLES.put("Automotive Engineer", engineeringRole(
            "Automotive Engineer", "Automotive Engineering",
            Arrays.asList("Vehicle Dynamics", "Automotive Systems", "Powertrain Engineering", "Electric Vehicle Systems", "Automotive CAD/CAE", "Control Systems", "CAN/LIN Networks", "Functional Safety (ISO 26262)", "Battery Management", "Testing and Validation"),
            "B.E./B.Tech in Automotive/Mechanical/Electrical Engineering or equivalent", "₹4,00,000 - ₹15,00,000 per year",
            new LearningResource("SAE International Learning", "https://www.sae.org/learn", "Paid", "Beginner", Arrays.asList("Vehicle Dynamics", "Automotive Systems", "Powertrain Engineering")),
            new LearningResource("NPTEL Electric Vehicle Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Electric Vehicle Systems", "Battery Management")),
            new LearningResource("MathWorks Automotive Resources", "https://www.mathworks.com/solutions/automotive.html", "Free", "Intermediate", Arrays.asList("Automotive CAD/CAE", "Control Systems", "CAN/LIN Networks", "Functional Safety (ISO 26262)")),
            new LearningResource("SAE Vehicle Testing and Validation", "https://www.sae.org/learn", "Paid", "Intermediate", Arrays.asList("Testing and Validation"))
        ));

        JOB_ROLES.put("Materials Engineer", engineeringRole(
            "Materials Engineer", "Materials & Metallurgical Engineering",
            Arrays.asList("Materials Science", "Metallurgy", "Materials Characterization", "Heat Treatment", "Failure Analysis", "Corrosion Engineering", "Materials Selection", "Mechanical Testing", "Phase Diagrams", "Quality Standards"),
            "B.E./B.Tech in Materials/Metallurgical Engineering or equivalent", "₹3,00,000 - ₹12,00,000 per year",
            new LearningResource("NPTEL Materials Science Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Materials Science", "Metallurgy", "Phase Diagrams")),
            new LearningResource("ASM International Learning", "https://www.asminternational.org/learning/", "Paid", "Intermediate", Arrays.asList("Heat Treatment", "Corrosion Engineering", "Failure Analysis", "Quality Standards")),
            new LearningResource("DoITPoMS Materials Teaching Resources", "https://www.doitpoms.ac.uk/", "Free", "Intermediate", Arrays.asList("Materials Characterization", "Materials Selection", "Mechanical Testing"))
        ));

        JOB_ROLES.put("Petroleum Engineer", engineeringRole(
            "Petroleum Engineer", "Petroleum Engineering",
            Arrays.asList("Reservoir Engineering", "Drilling Engineering", "Production Engineering", "Petroleum Geology", "Well Logging", "Reservoir Simulation", "Fluid Mechanics", "Well Completion", "Health, Safety & Environment", "Economic Evaluation"),
            "B.E./B.Tech in Petroleum/Chemical Engineering or equivalent", "₹5,00,000 - ₹20,00,000 per year",
            new LearningResource("SPE PetroWiki", "https://petrowiki.spe.org/PetroWiki", "Free", "Beginner", Arrays.asList("Reservoir Engineering", "Drilling Engineering", "Production Engineering", "Health, Safety & Environment")),
            new LearningResource("NPTEL Petroleum Engineering Courses", "https://nptel.ac.in/courses", "Free", "Beginner", Arrays.asList("Petroleum Geology", "Well Logging", "Fluid Mechanics")),
            new LearningResource("SLB Energy Glossary and Learning", "https://glossary.slb.com/", "Free", "Intermediate", Arrays.asList("Reservoir Simulation", "Well Completion", "Economic Evaluation"))
        ));
    }

    private static JobRole engineeringRole(String title, String category, List<String> skills,
            String education, String salary, LearningResource... resources) {
        return new JobRole(title, category, skills, Arrays.asList(resources), education, salary);
    }

    /**
     * Performs the skill gap analysis and returns a JSON response.
     */
    public static String analyze(String name, String age, String education, String desiredJob, String currentSkillsStr) {
        JobRole role = JOB_ROLES.get(desiredJob);
        if (role == null) {
            return "{\"error\": \"Job role not found: " + escapeJson(desiredJob) + "\"}";
        }

        // Parse current skills
        Set<String> currentSkills = new HashSet<>();
        if (currentSkillsStr != null && !currentSkillsStr.trim().isEmpty()) {
            for (String skill : parseSkillList(currentSkillsStr)) {
                if (!skill.trim().isEmpty()) {
                    currentSkills.add(skill.trim().toLowerCase());
                }
            }
        }

        // Determine which required skills the user already has and which they need
        List<String> matchedSkills = new ArrayList<>();
        List<String> missingSkills = new ArrayList<>();

        for (String requiredSkill : role.requiredSkills) {
            boolean hasSkill = false;
            for (String userSkill : currentSkills) {
                if (requiredSkill.toLowerCase().contains(userSkill) || userSkill.contains(requiredSkill.toLowerCase())) {
                    hasSkill = true;
                    break;
                }
            }
            if (hasSkill) {
                matchedSkills.add(requiredSkill);
            } else {
                missingSkills.add(requiredSkill);
            }
        }

        // Calculate readiness percentage
        int totalSkills = role.requiredSkills.size();
        int matchedCount = matchedSkills.size();
        int readinessPercent = totalSkills > 0 ? (matchedCount * 100) / totalSkills : 0;

        // Determine readiness level
        String readinessLevel;
        String readinessMessage;
        if (readinessPercent >= 80) {
            readinessLevel = "Advanced";
            readinessMessage = "Excellent! You're almost job-ready. Focus on the few remaining skills to become a strong candidate.";
        } else if (readinessPercent >= 50) {
            readinessLevel = "Intermediate";
            readinessMessage = "Good progress! You have a solid foundation. Dedicate time to learning the missing skills to stand out.";
        } else if (readinessPercent >= 25) {
            readinessLevel = "Beginner";
            readinessMessage = "You've made a start! There are several key skills to develop. Follow a structured learning path to build your expertise.";
        } else {
            readinessLevel = "Getting Started";
            readinessMessage = "This is a new field for you, but that's okay! Everyone starts somewhere. Follow the recommended resources to begin your journey.";
        }

        // Estimate learning time (rough: 2-4 weeks per skill)
        int estimatedWeeks = missingSkills.size() * 3;
        String estimatedTime;
        if (estimatedWeeks <= 4) {
            estimatedTime = estimatedWeeks + " weeks";
        } else {
            int months = estimatedWeeks / 4;
            estimatedTime = months + " - " + (months + 2) + " months";
        }

        // Build JSON response
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        json.append("  \"name\": \"").append(escapeJson(name)).append("\",\n");
        json.append("  \"age\": \"").append(escapeJson(age)).append("\",\n");
        json.append("  \"education\": \"").append(escapeJson(education)).append("\",\n");
        json.append("  \"desiredJob\": \"").append(escapeJson(desiredJob)).append("\",\n");
        json.append("  \"category\": \"").append(escapeJson(role.category)).append("\",\n");
        json.append("  \"readinessPercent\": ").append(readinessPercent).append(",\n");
        json.append("  \"readinessLevel\": \"").append(readinessLevel).append("\",\n");
        json.append("  \"readinessMessage\": \"").append(escapeJson(readinessMessage)).append("\",\n");
        json.append("  \"recommendedEducation\": \"").append(escapeJson(role.recommendedEducation)).append("\",\n");
        json.append("  \"salaryRange\": \"").append(escapeJson(role.salaryRange)).append("\",\n");
        json.append("  \"estimatedLearningTime\": \"").append(escapeJson(estimatedTime)).append("\",\n");
        json.append("  \"totalRequiredSkills\": ").append(totalSkills).append(",\n");
        json.append("  \"matchedSkillsCount\": ").append(matchedCount).append(",\n");
        json.append("  \"missingSkillsCount\": ").append(missingSkills.size()).append(",\n");

        // Matched skills array
        json.append("  \"matchedSkills\": [");
        for (int i = 0; i < matchedSkills.size(); i++) {
            json.append("\"").append(escapeJson(matchedSkills.get(i))).append("\"");
            if (i < matchedSkills.size() - 1) json.append(", ");
        }
        json.append("],\n");

        // Missing skills array
        json.append("  \"missingSkills\": [");
        for (int i = 0; i < missingSkills.size(); i++) {
            json.append("\"").append(escapeJson(missingSkills.get(i))).append("\"");
            if (i < missingSkills.size() - 1) json.append(", ");
        }
        json.append("],\n");

        // All required skills
        json.append("  \"allRequiredSkills\": [");
        for (int i = 0; i < role.requiredSkills.size(); i++) {
            json.append("\"").append(escapeJson(role.requiredSkills.get(i))).append("\"");
            if (i < role.requiredSkills.size() - 1) json.append(", ");
        }
        json.append("],\n");

        // Learning resources
        json.append("  \"learningResources\": [\n");
        boolean firstResource = true;
        for (int i = 0; i < role.resources.size(); i++) {
            LearningResource res = role.resources.get(i);
            if (!res.skills.isEmpty() && Collections.disjoint(res.skills, missingSkills)) {
                continue;
            }
            List<String> relevantSkills = new ArrayList<>(res.skills);
            relevantSkills.retainAll(missingSkills);
            if (!firstResource) json.append(",\n");
            json.append("    {\"title\": \"").append(escapeJson(res.title))
                .append("\", \"url\": \"").append(escapeJson(res.url))
                .append("\", \"cost\": \"").append(escapeJson(res.cost))
                .append("\", \"level\": \"").append(escapeJson(res.level))
                .append("\", \"skills\": [");
            for (int skillIndex = 0; skillIndex < relevantSkills.size(); skillIndex++) {
                json.append("\"").append(escapeJson(relevantSkills.get(skillIndex))).append("\"");
                if (skillIndex < relevantSkills.size() - 1) json.append(", ");
            }
            json.append("]}");
            firstResource = false;
            json.append("\n");
        }
        json.append("  ]\n");

        json.append("}");

        return json.toString();
    }

    /**
     * Returns a JSON array of all available job roles grouped by category.
     */
    public static String getJobRolesJson() {
        // Group by category
        Map<String, List<String>> grouped = new LinkedHashMap<>();
        for (Map.Entry<String, JobRole> entry : JOB_ROLES.entrySet()) {
            String category = entry.getValue().category;
            grouped.computeIfAbsent(category, k -> new ArrayList<>()).add(entry.getKey());
        }

        StringBuilder json = new StringBuilder();
        json.append("{\n  \"categories\": [\n");

        int catIndex = 0;
        for (Map.Entry<String, List<String>> entry : grouped.entrySet()) {
            json.append("    {\n");
            json.append("      \"name\": \"").append(escapeJson(entry.getKey())).append("\",\n");
            json.append("      \"jobs\": [");
            for (int i = 0; i < entry.getValue().size(); i++) {
                json.append("\"").append(escapeJson(entry.getValue().get(i))).append("\"");
                if (i < entry.getValue().size() - 1) json.append(", ");
            }
            json.append("]\n");
            json.append("    }");
            if (catIndex < grouped.size() - 1) json.append(",");
            json.append("\n");
            catIndex++;
        }

        json.append("  ]\n}");
        return json.toString();
    }

    public static String getRequiredSkillsJson(String desiredJob) {
        JobRole role = JOB_ROLES.get(desiredJob);
        if (role == null) return "{\"skills\":[]}";
        StringBuilder json = new StringBuilder("{\"skills\":[");
        for (int i = 0; i < role.requiredSkills.size(); i++) {
            if (i > 0) json.append(',');
            json.append('\"').append(escapeJson(role.requiredSkills.get(i))).append('\"');
        }
        return json.append("]}").toString();
    }

    private static List<String> parseSkillList(String value) {
        List<String> skills = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (ch == '"') {
                if (quoted && i + 1 < value.length() && value.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    quoted = !quoted;
                }
            } else if (ch == ',' && !quoted) {
                if (!current.toString().trim().isEmpty()) skills.add(current.toString().trim());
                current.setLength(0);
            } else {
                current.append(ch);
            }
        }
        if (!current.toString().trim().isEmpty()) skills.add(current.toString().trim());
        return skills;
    }

    private static String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }

    // ─── Inner Classes ────────────────────────────────────────────────────

    static class JobRole {
        String title;
        String category;
        List<String> requiredSkills;
        List<LearningResource> resources;
        String recommendedEducation;
        String salaryRange;

        JobRole(String title, String category, List<String> requiredSkills,
                List<LearningResource> resources, String recommendedEducation, String salaryRange) {
            this.title = title;
            this.category = category;
            this.requiredSkills = requiredSkills;
            this.resources = resources;
            this.recommendedEducation = recommendedEducation;
            this.salaryRange = salaryRange;
        }
    }

    static class LearningResource {
        String title;
        String url;
        String cost;
        String level;
        List<String> skills;

        LearningResource(String title, String url, String cost, String level) {
            this(title, url, cost, level, Collections.emptyList());
        }

        LearningResource(String title, String url, String cost, String level, List<String> skills) {
            this.title = title;
            this.url = url;
            this.cost = cost;
            this.level = level;
            this.skills = skills;
        }
    }
}
