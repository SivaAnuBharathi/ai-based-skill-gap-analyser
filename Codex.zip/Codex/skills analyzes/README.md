# SkillBridge — Skill Gap Analyser

## Deploy to Vercel

1. Push this repository to GitHub.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Keep the project root set to the repository root. The included `vercel.json` serves the `frontend` directory and deploys the API functions in `api`.
4. Choose **Other** if Vercel asks for a framework preset, then deploy.

The deployed site includes `/api/jobs`, `/api/analyze`, and the Gemini-powered `/api/assistant`; it does not need the local Java server. Job roles and salary ranges are maintained in both `api/roles.json` (deployed API) and the Java analyzer (local server).

## Configure the AI Career Guide

The AI Career Guide uses the Gemini API. Create a key in [Google AI Studio](https://aistudio.google.com/app/apikey) and set `GEMINI_API_KEY` as a **server-side environment variable**; never put the key in frontend files or commit it.

- **Vercel:** Open the project's **Settings → Environment Variables**, add `GEMINI_API_KEY`, then redeploy. The API key is used by `/api/assistant`.
- **Local Java server (Windows):** In PowerShell, run `$env:GEMINI_API_KEY = "your Gemini API key"` and then `.\run.bat` in the project folder. Keep that terminal open while using the site.

The guide sends your chat messages and, when available, selected career/skills to Gemini. It does not send your name or age. Don't enter private information in chat. Gemini usage may be subject to Google's account, availability, and billing terms. Without a configured key, the website and skill analysis still work; the assistant shows a setup message.

For local development, use JDK 11 or newer, run `run.bat`, and open `http://localhost:8080`.
