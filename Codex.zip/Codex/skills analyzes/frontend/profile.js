const supabaseClient = window.supabaseClient;
let signedInUser = null;

document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session?.user) {
        window.location.replace('account.html');
        return;
    }
    signedInUser = session.user;
    document.getElementById('profile-email').value = signedInUser.email || '';
    document.getElementById('profile-name').value = signedInUser.user_metadata?.full_name || '';

    const { data: profile, error } = await supabaseClient.from('profiles')
        .select('full_name, age, education').eq('id', signedInUser.id).maybeSingle();
    if (error) {
        document.getElementById('profile-status').textContent =
            'Profile storage is not set up yet. Run the profiles table SQL in Supabase, then refresh this page.';
        console.error('Could not load profile:', error);
    } else if (profile) {
        document.getElementById('profile-name').value = profile.full_name || signedInUser.user_metadata?.full_name || '';
        document.getElementById('profile-age').value = profile.age || '';
        document.getElementById('profile-education').value = profile.education || '';
        document.getElementById('profile-status').textContent = 'Your details are private to your account.';
    } else {
        document.getElementById('profile-status').textContent = 'Add your details and save them to your private profile.';
    }

    document.getElementById('profile-form').addEventListener('submit', saveProfile);
    document.getElementById('logout-button').addEventListener('click', async () => {
        const { error: signOutError } = await supabaseClient.auth.signOut();
        if (signOutError) document.getElementById('profile-status').textContent = signOutError.message;
        else window.location.replace('account.html');
    });
    document.getElementById('refresh-saved-results').addEventListener('click', loadSavedAnalyses);
    await loadSavedAnalyses();
});

async function saveProfile(event) {
    event.preventDefault();
    const status = document.getElementById('profile-status');
    const button = document.getElementById('save-profile-button');
    button.disabled = true;
    status.textContent = 'Saving your details…';
    const { error } = await supabaseClient.from('profiles').upsert({
        id: signedInUser.id,
        full_name: document.getElementById('profile-name').value.trim(),
        age: document.getElementById('profile-age').value ? Number(document.getElementById('profile-age').value) : null,
        education: document.getElementById('profile-education').value,
        updated_at: new Date().toISOString()
    });
    button.disabled = false;
    status.textContent = error ? `Could not save profile: ${error.message}` : 'Your profile details are saved.';
}

async function loadSavedAnalyses() {
    const list = document.getElementById('saved-results-list');
    const refreshButton = document.getElementById('refresh-saved-results');
    refreshButton.disabled = true;
    refreshButton.textContent = 'Loading…';
    list.textContent = 'Loading your analyses…';
    const { data, error } = await supabaseClient.from('analysis_results')
        .select('id, created_at, desired_job, education, current_skills, matched_skills, missing_skills, readiness_percent, readiness_level')
        .order('created_at', { ascending: false }).limit(20);
    if (error) {
        console.error('Could not load saved analyses:', error);
        list.textContent = 'Your history could not be loaded. Check your connection and try again.';
        refreshButton.disabled = false;
        refreshButton.textContent = 'Try again';
        return;
    }
    refreshButton.disabled = false;
    refreshButton.textContent = 'Refresh';
    list.replaceChildren();
    if (!data?.length) {
        list.textContent = 'No saved analyses yet. Run an analysis from Home while signed in.';
        return;
    }
    data.forEach(result => {
        const card = document.createElement('article');
        card.className = 'saved-analysis-card';
        const top = document.createElement('div'); top.className = 'saved-analysis-top';
        const title = document.createElement('h3'); title.textContent = result.desired_job || 'Career analysis';
        const score = document.createElement('span'); score.className = 'saved-analysis-score'; score.textContent = `${result.readiness_percent ?? 0}% ready`;
        const meta = document.createElement('p'); meta.className = 'saved-analysis-meta';
        meta.textContent = `${result.readiness_level || 'Analysis'} · ${new Date(result.created_at).toLocaleDateString()}${result.education ? ` · ${result.education}` : ''}`;
        top.append(title, score); card.append(top, meta);
        const details = document.createElement('details'); details.className = 'saved-analysis-details';
        const summary = document.createElement('summary'); summary.textContent = 'View skill breakdown';
        const current = document.createElement('p'); current.textContent = `Your skills: ${(result.current_skills || []).join(', ') || 'Not listed'}`;
        const matched = document.createElement('p'); matched.textContent = `Matched: ${(result.matched_skills || []).join(', ') || 'None'}`;
        const missing = document.createElement('p'); missing.textContent = `To learn: ${(result.missing_skills || []).join(', ') || 'None'}`;
        details.append(summary, current, matched, missing); card.appendChild(details);
        const actions = document.createElement('div'); actions.className = 'history-card-actions';
        const viewButton = document.createElement('button'); viewButton.type = 'button'; viewButton.className = 'history-view-button';
        viewButton.textContent = 'View breakdown';
        viewButton.addEventListener('click', () => {
            details.open = !details.open;
            viewButton.textContent = details.open ? 'Hide breakdown' : 'View breakdown';
        });
        const deleteButton = document.createElement('button'); deleteButton.type = 'button'; deleteButton.className = 'history-delete-button';
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', async () => {
            if (!window.confirm(`Delete the saved analysis for ${result.desired_job || 'this role'}?`)) return;
            deleteButton.disabled = true;
            const { error: deleteError } = await supabaseClient.from('analysis_results').delete().eq('id', result.id);
            if (deleteError) {
                deleteButton.disabled = false;
                window.alert('Could not delete this analysis. Check your Supabase delete policy and try again.');
                console.error('Could not delete analysis:', deleteError);
                return;
            }
            card.remove();
            if (!list.querySelector('.saved-analysis-card')) list.textContent = 'No saved analyses yet. Run an analysis from Home while signed in.';
        });
        actions.append(viewButton, deleteButton); card.appendChild(actions); list.appendChild(card);
    });
}
