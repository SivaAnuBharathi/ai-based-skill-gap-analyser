const supabaseClient = window.supabaseClient;

document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (session) {
        window.location.replace('index.html');
        return;
    }

    const form = document.getElementById('auth-form');
    const nameInput = document.getElementById('auth-name');
    const nameLabel = document.getElementById('auth-name-label');
    const emailInput = document.getElementById('auth-email');
    const passwordInput = document.getElementById('auth-password');
    const signupButton = document.getElementById('signup-button');
    const signinButton = document.getElementById('signin-button');
    const title = document.getElementById('auth-title');
    const status = document.getElementById('auth-status');
    const passwordToggle = document.getElementById('toggle-password');
    let creatingAccount = false;

    passwordToggle.addEventListener('click', () => {
        const showPassword = passwordInput.type === 'password';
        passwordInput.type = showPassword ? 'text' : 'password';
        passwordToggle.textContent = showPassword ? 'Hide' : 'Show';
        passwordToggle.setAttribute('aria-label', showPassword ? 'Hide password' : 'Show password');
        passwordToggle.setAttribute('aria-pressed', String(showPassword));
    });

    signupButton.addEventListener('click', async () => {
        if (!creatingAccount) {
            creatingAccount = true;
            nameInput.hidden = false;
            nameLabel.hidden = false;
            nameInput.required = true;
            passwordInput.autocomplete = 'new-password';
            title.textContent = 'Create your account';
            signinButton.textContent = 'Create account';
            signupButton.textContent = 'Back to sign in';
            status.textContent = 'Add your name, email, and a password to get started.';
            nameInput.focus();
            return;
        }
        creatingAccount = false;
        nameInput.hidden = true;
        nameLabel.hidden = true;
        nameInput.required = false;
        nameInput.value = '';
        passwordInput.autocomplete = 'current-password';
        title.textContent = 'Welcome back';
        signinButton.textContent = 'Sign in';
        signupButton.textContent = 'Create account';
        status.textContent = 'Your saved analyses are private to your account.';
    });

    form.addEventListener('submit', async event => {
        event.preventDefault();
        setAuthButtonsDisabled(true);
        if (creatingAccount) {
            status.textContent = 'Creating your account…';
            const { data, error } = await supabaseClient.auth.signUp({
                email: emailInput.value.trim(),
                password: passwordInput.value,
                options: { data: { full_name: nameInput.value.trim() } }
            });
            setAuthButtonsDisabled(false);
            if (error) {
                status.textContent = friendlyAuthError(error);
            } else if (data.session) {
                window.location.replace('index.html');
            } else {
                creatingAccount = false;
                nameInput.hidden = true;
                nameLabel.hidden = true;
                nameInput.required = false;
                passwordInput.value = '';
                title.textContent = 'Check your email';
                signinButton.textContent = 'Sign in';
                signupButton.textContent = 'Create account';
                status.textContent = 'Account created. Confirm your email, then sign in here.';
            }
            return;
        }

        status.textContent = 'Signing in…';
        const { error } = await supabaseClient.auth.signInWithPassword({
            email: emailInput.value.trim(),
            password: passwordInput.value
        });
        setAuthButtonsDisabled(false);
        if (error) status.textContent = friendlyAuthError(error);
        else window.location.replace('index.html');
    });
});

function setAuthButtonsDisabled(disabled) {
    document.querySelectorAll('#auth-form button').forEach(button => { button.disabled = disabled; });
}

function friendlyAuthError(error) {
    const message = (error.message || '').toLowerCase();
    if (message.includes('invalid login credentials')) return 'That email and password do not match. Check them and try again.';
    if (message.includes('already registered')) return 'There is already an account for this email. Try signing in instead.';
    if (message.includes('password')) return 'Use a password with at least 6 characters.';
    if (message.includes('email')) return 'Check that your email address is entered correctly.';
    return error.message || 'Something went wrong. Please try again.';
}
