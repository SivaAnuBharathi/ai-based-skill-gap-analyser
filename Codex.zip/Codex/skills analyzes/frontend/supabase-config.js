window.supabaseClient = window.supabase.createClient(
    'https://npdieuvqyjgagewalcox.supabase.co',
    'sb_publishable_gxb5qcxAaxZ85OqXpYdF2Q_pWtM-Lqi'
);
