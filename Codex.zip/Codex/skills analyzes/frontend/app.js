/**
 * SkillBridge — Skill Gap Analyser
 * Frontend Application Logic
 */

// ─── Configuration ───
const supabaseClient = window.supabaseClient;

const API_BASE = window.location.origin;
let currentStep = 1;
let analysisData = null;
let signedInUser = null;
let resumeAddedSkills = [];
let suggestedSkills = [];
const assistantHistory = [];

// ─── Initialize ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await supabaseClient.auth.getSession();
    signedInUser = session?.user || null;
    const analyzeSection = document.getElementById('analyze');
    const analyzeNav = document.getElementById('nav-analyze');
    const profileNav = document.getElementById('nav-profile');
    const authNav = document.getElementById('nav-auth');
    analyzeSection.hidden = !signedInUser;
    analyzeNav.hidden = !signedInUser;
    profileNav.hidden = !signedInUser;
    authNav.hidden = Boolean(signedInUser);
    if (signedInUser) await loadPersonalDetails(signedInUser);
    loadJobRoles();
    setupSkillTagsInput();
    setupSkillSuggestions();
    setupResumeUpload();
    setupScrollAnimations();
    setupNavbarScroll();
    setupAssistant();
});

async function loadPersonalDetails(user) {
    const nameInput = document.getElementById('input-name');
    if (user.user_metadata?.full_name) nameInput.value = user.user_metadata.full_name;
    const { data, error } = await supabaseClient.from('profiles')
        .select('full_name, age, education').eq('id', user.id).maybeSingle();
    if (error) {
        console.error('Could not load saved personal details:', error);
        return;
    }
    if (!data) return;
    nameInput.value = data.full_name || nameInput.value;
    document.getElementById('input-age').value = data.age || '';
    document.getElementById('input-education').value = data.education || '';
}

// ─── Navigation ──────────────────────────────────────────────────────
function scrollToAnalyze() {
    if (!signedInUser) {
        window.location.assign('account.html');
        return;
    }
    document.getElementById('analyze').scrollIntoView({ behavior: 'smooth' });
}

function scrollToHowItWorks() {
    document.getElementById('how-it-works').scrollIntoView({ behavior: 'smooth' });
}

// ─── AI Career Guide ──────────────────────────────────────────────────
function setupAssistant() {
    document.getElementById('assistant-launcher').addEventListener('click', openAssistant);
    document.getElementById('assistant-close').addEventListener('click', closeAssistant);
    document.getElementById('assistant-form').addEventListener('submit', event => {
        event.preventDefault();
        sendAssistantMessage();
    });
    document.getElementById('assistant-suggestions').addEventListener('click', event => {
        const button = event.target.closest('[data-assistant-prompt]');
        if (!button) return;
        document.getElementById('assistant-input').value = button.dataset.assistantPrompt;
        sendAssistantMessage();
    });
}

function openAssistant() {
    const panel = document.getElementById('assistant-panel');
    panel.classList.add('open');
    panel.setAttribute('aria-hidden', 'false');
    document.getElementById('assistant-launcher').setAttribute('aria-expanded', 'true');
    document.getElementById('assistant-input').focus();
}

function closeAssistant() {
    document.getElementById('assistant-panel').classList.remove('open');
    document.getElementById('assistant-panel').setAttribute('aria-hidden', 'true');
    document.getElementById('assistant-launcher').setAttribute('aria-expanded', 'false');
    document.getElementById('assistant-launcher').focus();
}

async function sendAssistantMessage() {
    const input = document.getElementById('assistant-input');
    const message = input.value.trim();
    if (!message || message.length > 1000) return;

    const sendButton = document.getElementById('assistant-send');
    const messages = document.getElementById('assistant-messages');
    const suggestions = document.getElementById('assistant-suggestions');
    const role = analysisData?.desiredJob || document.getElementById('input-job').value;
    const skills = analysisData
        ? [...analysisData.matchedSkills, ...analysisData.missingSkills].join(', ')
        : document.getElementById('input-skills').value.trim();

    appendAssistantMessage(message, 'user');
    input.value = '';
    input.disabled = true;
    sendButton.disabled = true;
    suggestions.hidden = true;
    const typing = appendAssistantMessage('Thinking…', 'ai');

    try {
        const response = await fetch(`${API_BASE}/api/assistant`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message,
                history: assistantHistory.slice(-12),
                role,
                skills
            })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'The AI assistant could not reply.');

        typing.textContent = result.reply;
        assistantHistory.push({ role: 'user', text: message });
        assistantHistory.push({ role: 'model', text: result.reply });
    } catch (error) {
        console.error('AI assistant error:', error);
        typing.textContent = error.message;
        typing.classList.add('assistant-message-error');
    } finally {
        input.disabled = false;
        sendButton.disabled = false;
        input.focus();
        messages.scrollTop = messages.scrollHeight;
    }
}

function appendAssistantMessage(text, sender) {
    const messages = document.getElementById('assistant-messages');
    const message = document.createElement('div');
    message.className = `assistant-message assistant-message-${sender}`;
    message.textContent = text;
    messages.appendChild(message);
    messages.scrollTop = messages.scrollHeight;
    return message;
}

function setupNavbarScroll() {
    const navbar = document.getElementById('navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = [
        { section: 'home', link: 'nav-home' },
        { section: 'how-it-works', link: 'nav-how' },
        { section: 'analyze', link: 'nav-analyze' },
        { section: 'results-section', link: 'nav-analyze' }
    ];

    window.addEventListener('scroll', () => {
        // Navbar background
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(9, 9, 11, 0.9)';
        } else {
            navbar.style.background = 'rgba(9, 9, 11, 0.7)';
        }

        // Active nav link
        const scrollPos = window.scrollY + 200;
        sections.forEach(({ section: sectionId, link: linkId }) => {
            const section = document.getElementById(sectionId);
            if (section) {
                const top = section.offsetTop;
                const bottom = top + section.offsetHeight;
                if (scrollPos >= top && scrollPos < bottom) {
                    navLinks.forEach(link => link.classList.remove('active'));
                    document.getElementById(linkId)?.classList.add('active');
                }
            }
        });
    });
}

// ─── Load Job Roles ──────────────────────────────────────────────────
async function loadJobRoles() {
    const select = document.getElementById('input-job');
    
    try {
        const response = await fetch(`${API_BASE}/api/jobs`);
        if (!response.ok) throw new Error('Failed to load job roles');
        
        const data = await response.json();
        
        select.innerHTML = '<option value="" disabled selected>Choose your dream job role</option>';
        
        data.categories.forEach(category => {
            const optgroup = document.createElement('optgroup');
            optgroup.label = `── ${category.name} ──`;
            
            category.jobs.forEach(job => {
                const option = document.createElement('option');
                option.value = job;
                option.textContent = job;
                optgroup.appendChild(option);
            });
            
            select.appendChild(optgroup);
        });
    } catch (error) {
        console.error('Error loading job roles:', error);
        select.innerHTML = `
            <option value="" disabled selected>Choose your dream job role</option>
            <optgroup label="── Software Development ──">
                <option value="Frontend Developer">Frontend Developer</option>
                <option value="Backend Developer">Backend Developer</option>
                <option value="Full Stack Developer">Full Stack Developer</option>
                <option value="Mobile App Developer">Mobile App Developer</option>
                <option value="DevOps Engineer">DevOps Engineer</option>
                <option value="QA Engineer">QA Engineer</option>
            </optgroup>
            <optgroup label="── Data & AI ──">
                <option value="Data Scientist">Data Scientist</option>
                <option value="Data Analyst">Data Analyst</option>
                <option value="ML Engineer">ML Engineer</option>
                <option value="AI Engineer">AI Engineer</option>
            </optgroup>
            <optgroup label="── Cybersecurity ──">
                <option value="Cybersecurity Analyst">Cybersecurity Analyst</option>
                <option value="Ethical Hacker">Ethical Hacker</option>
            </optgroup>
            <optgroup label="── Design ──">
                <option value="UI/UX Designer">UI/UX Designer</option>
                <option value="Graphic Designer">Graphic Designer</option>
            </optgroup>
            <optgroup label="── Cloud & Infrastructure ──">
                <option value="Cloud Architect">Cloud Architect</option>
                <option value="Database Administrator">Database Administrator</option>
            </optgroup>
            <optgroup label="── Product & Management ──">
                <option value="Product Manager">Product Manager</option>
                <option value="Project Manager">Project Manager</option>
            </optgroup>
            <optgroup label="── Digital Marketing ──">
                <option value="Digital Marketing Specialist">Digital Marketing Specialist</option>
            </optgroup>
            <optgroup label="── Emerging Technologies ──">
                <option value="Blockchain Developer">Blockchain Developer</option>
            </optgroup>
            <optgroup label="── Mechanical Engineering ──">
                <option value="Mechanical Design Engineer">Mechanical Design Engineer</option>
            </optgroup>
            <optgroup label="── Electrical Engineering ──">
                <option value="Electrical Engineer">Electrical Engineer</option>
            </optgroup>
            <optgroup label="── Civil Engineering ──">
                <option value="Civil Engineer">Civil Engineer</option>
            </optgroup>
            <optgroup label="── Chemical Engineering ──">
                <option value="Chemical Process Engineer">Chemical Process Engineer</option>
            </optgroup>
            <optgroup label="── Aerospace Engineering ──">
                <option value="Aerospace Engineer">Aerospace Engineer</option>
            </optgroup>
            <optgroup label="── Biomedical Engineering ──">
                <option value="Biomedical Engineer">Biomedical Engineer</option>
            </optgroup>
            <optgroup label="── Industrial Engineering ──">
                <option value="Industrial Engineer">Industrial Engineer</option>
            </optgroup>
            <optgroup label="── Environmental Engineering ──">
                <option value="Environmental Engineer">Environmental Engineer</option>
            </optgroup>
            <optgroup label="── Electronics & Communication Engineering ──">
                <option value="Embedded Systems Engineer">Embedded Systems Engineer</option>
            </optgroup>
            <optgroup label="── Mechatronics & Robotics ──">
                <option value="Robotics Engineer">Robotics Engineer</option>
            </optgroup>
            <optgroup label="── Automotive Engineering ──">
                <option value="Automotive Engineer">Automotive Engineer</option>
            </optgroup>
            <optgroup label="── Materials & Metallurgical Engineering ──">
                <option value="Materials Engineer">Materials Engineer</option>
            </optgroup>
            <optgroup label="── Petroleum Engineering ──">
                <option value="Petroleum Engineer">Petroleum Engineer</option>
            </optgroup>
        `;
    }
}

// ─── Skill Tags Input ────────────────────────────────────────────────
function setupSkillTagsInput() {
    const textarea = document.getElementById('input-skills');
    const tagsContainer = document.getElementById('skill-tags');

    textarea.addEventListener('input', () => {
        updateSkillTags();
        renderSkillSuggestions();
    });
}

function setupSkillSuggestions() {
    const jobSelect = document.getElementById('input-job');
    const panel = document.getElementById('skill-suggestions-panel');
    jobSelect.addEventListener('change', () => loadSkillSuggestions(jobSelect.value));
    if (jobSelect.value) loadSkillSuggestions(jobSelect.value);
    panel.addEventListener('click', event => {
        const chip = event.target.closest('[data-suggested-skill]');
        if (!chip) return;
        const skill = chip.dataset.suggestedSkill;
        const textarea = document.getElementById('input-skills');
        const current = parseSkillEntries(textarea.value);
        const existingIndex = current.findIndex(value => value.toLowerCase() === skill.toLowerCase());
        if (existingIndex >= 0) current.splice(existingIndex, 1);
        else current.push(skill);
        textarea.value = formatSkillEntries(current);
        updateSkillTags();
        renderSkillSuggestions();
    });
}

async function loadSkillSuggestions(job) {
    const panel = document.getElementById('skill-suggestions-panel');
    const list = document.getElementById('skill-suggestions-list');
    if (!job) {
        panel.hidden = true;
        suggestedSkills = [];
        return;
    }
    panel.hidden = false;
    list.textContent = 'Loading suggestions…';
    try {
        const response = await fetch(`${API_BASE}/api/skills?job=${encodeURIComponent(job)}`);
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not load suggestions.');
        suggestedSkills = result.skills || [];
        renderSkillSuggestions();
    } catch (error) {
        console.error('Could not load skill suggestions:', error);
        list.textContent = 'Suggestions are unavailable right now. You can still type your skills above.';
    }
}

function renderSkillSuggestions() {
    const list = document.getElementById('skill-suggestions-list');
    const current = new Set(parseSkillEntries(document.getElementById('input-skills').value).map(skill => skill.toLowerCase()));
    list.replaceChildren();
    if (!suggestedSkills.length) {
        list.textContent = 'No suggestions are available for this role.';
        return;
    }
    suggestedSkills.forEach(skill => {
        const selected = current.has(skill.toLowerCase());
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `skill-suggestion-chip${selected ? ' selected' : ''}`;
        button.dataset.suggestedSkill = skill;
        button.setAttribute('aria-pressed', String(selected));
        button.textContent = `${selected ? '✓ ' : '+ '}${skill}`;
        list.appendChild(button);
    });
}

function parseSkillEntries(value) {
    const entries = [];
    let current = '';
    let quoted = false;
    for (let i = 0; i < value.length; i++) {
        const char = value[i];
        if (char === '"') {
            if (quoted && value[i + 1] === '"') { current += '"'; i++; }
            else quoted = !quoted;
        } else if (char === ',' && !quoted) {
            if (current.trim()) entries.push(current.trim());
            current = '';
        } else current += char;
    }
    if (current.trim()) entries.push(current.trim());
    return entries;
}

function formatSkillEntries(entries) {
    return entries.map(skill => {
        const escaped = skill.replace(/"/g, '""');
        return /[,"\n]/.test(skill) ? `"${escaped}"` : skill;
    }).join(', ');
}

function setupResumeUpload() {
    const fileInput = document.getElementById('resume-file');
    const status = document.getElementById('resume-status');
    if (!fileInput || !status) return;

    fileInput.addEventListener('change', async () => {
        const file = fileInput.files?.[0];
        if (!file) return;
        if (file.size > 8 * 1024 * 1024) {
            status.textContent = 'That file is larger than 8 MB. Choose a smaller resume.';
            fileInput.value = '';
            return;
        }

        const job = document.getElementById('input-job').value;
        if (!job) {
            status.textContent = 'Choose your desired job role first, then add your resume.';
            fileInput.value = '';
            return;
        }

        status.textContent = 'Reading your resume on this device…';
        fileInput.disabled = true;
        try {
            const resumeText = await extractResumeText(file);
            if (!resumeText.trim()) throw new Error('No readable text was found. Try a text-based PDF, DOCX, or TXT file.');

            const response = await fetch(`${API_BASE}/api/skills?job=${encodeURIComponent(job)}`);
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'Could not check skills for this job role.');
            const foundSkills = (result.skills || []).filter(skill => resumeContainsSkill(resumeText, skill));

            const textarea = document.getElementById('input-skills');
            const previouslyAdded = new Set(resumeAddedSkills.map(skill => skill.toLowerCase()));
            const currentManualSkills = parseSkillEntries(textarea.value)
                .filter(skill => !previouslyAdded.has(skill.toLowerCase()));
            const combined = [...currentManualSkills];
            [...currentManualSkills, ...foundSkills].forEach(skill => {
                if (!combined.some(existing => existing.toLowerCase() === skill.toLowerCase())) combined.push(skill);
            });
            textarea.value = formatSkillEntries(combined);
            resumeAddedSkills = foundSkills;
            updateSkillTags();
            renderSkillSuggestions();

            status.textContent = foundSkills.length
                ? `Found ${foundSkills.length} job-related skill${foundSkills.length === 1 ? '' : 's'} and added them below. Review or edit the list before continuing. Your resume file stays on this device.`
                : 'No listed job skills were recognized in this resume. You can enter skills above instead. Your resume file stays on this device.';
        } catch (error) {
            console.error('Could not read resume:', error);
            status.textContent = error.message || 'Could not read that file. Try a PDF, DOCX, or TXT resume.';
        } finally {
            fileInput.disabled = false;
        }
    });
}

async function extractResumeText(file) {
    const extension = file.name.toLowerCase().split('.').pop();
    if (extension === 'txt') return file.text();

    const arrayBuffer = await file.arrayBuffer();
    if (extension === 'docx') {
        if (!window.mammoth) throw new Error('The Word document reader did not load. Refresh the page and try again.');
        const result = await window.mammoth.extractRawText({ arrayBuffer });
        return result.value || '';
    }
    if (extension === 'pdf') {
        const pdfjs = await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.1.91/pdf.min.mjs');
        pdfjs.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.1.91/pdf.worker.min.mjs';
        const pdf = await pdfjs.getDocument({ data: new Uint8Array(arrayBuffer) }).promise;
        if (pdf.numPages > 30) throw new Error('This resume has more than 30 pages. Choose a shorter file.');
        const pages = [];
        for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
            const page = await pdf.getPage(pageNumber);
            const content = await page.getTextContent();
            pages.push(content.items.map(item => item.str || '').join(' '));
        }
        return pages.join('\n');
    }
    throw new Error('Choose a PDF, DOCX, or TXT file. Older .doc files are not supported.');
}

function resumeContainsSkill(resumeText, skill) {
    const normalize = value => value.toLowerCase().replace(/[^a-z0-9+#]+/g, ' ').trim().replace(/\s+/g, ' ');
    const text = ` ${normalize(resumeText)} `;
    const alternatives = [skill, ...(skill.match(/\(([^)]+)\)/)?.[1]?.split(/[\/|,]|\s+or\s+|\s+and\s+/i) || [])];
    if (/\s+or\s+/i.test(skill)) alternatives.push(...skill.split(/\s+or\s+/i));
    if (skill.includes('/')) alternatives.push(...skill.split('/'));
    return alternatives.some(value => {
        const term = normalize(value.replace(/[()]/g, ''));
        return Boolean(term) && text.includes(` ${term} `);
    });
}

function updateSkillTags() {
    const textarea = document.getElementById('input-skills');
    const tagsContainer = document.getElementById('skill-tags');
    const value = textarea.value.trim();

    tagsContainer.innerHTML = '';

    if (!value) return;

    const skills = parseSkillEntries(value);
    skills.forEach(skill => {
        const tag = document.createElement('span');
        tag.className = 'skill-tag';
        tag.innerHTML = `
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                <circle cx="6" cy="6" r="3" fill="currentColor" opacity="0.5"/>
            </svg>
            ${escapeHtml(skill)}
        `;
        tagsContainer.appendChild(tag);
    });
}

// ─── Multi-Step Form Logic ───────────────────────────────────────────
function nextStep(current) {
    if (!validateStep(current)) return;

    const currentStepEl = document.getElementById(`form-step-${current}`);
    const nextStepEl = document.getElementById(`form-step-${current + 1}`);

    if (currentStepEl && nextStepEl) {
        currentStepEl.classList.remove('active');
        nextStepEl.classList.add('active');
        currentStep = current + 1;
        updateProgress();
    }
}

function prevStep(current) {
    const currentStepEl = document.getElementById(`form-step-${current}`);
    const prevStepEl = document.getElementById(`form-step-${current - 1}`);

    if (currentStepEl && prevStepEl) {
        currentStepEl.classList.remove('active');
        prevStepEl.classList.add('active');
        currentStep = current - 1;
        updateProgress();
    }
}

function updateProgress() {
    for (let i = 1; i <= 3; i++) {
        const stepEl = document.getElementById(`prog-step-${i}`);
        const lineEl = document.getElementById(`prog-line-${i}`);

        if (i < currentStep) {
            stepEl.classList.remove('active');
            stepEl.classList.add('completed');
        } else if (i === currentStep) {
            stepEl.classList.add('active');
            stepEl.classList.remove('completed');
        } else {
            stepEl.classList.remove('active', 'completed');
        }

        if (lineEl) {
            if (i < currentStep) {
                lineEl.classList.add('active');
            } else {
                lineEl.classList.remove('active');
            }
        }
    }
}

// ─── Form Validation ─────────────────────────────────────────────────
function validateStep(step) {
    let isValid = true;

    if (step === 1) {
        const name = document.getElementById('input-name');
        const age = document.getElementById('input-age');
        const education = document.getElementById('input-education');

        if (!name.value.trim()) {
            showFieldError(name, 'Please enter your name');
            isValid = false;
        } else {
            clearFieldError(name);
        }

        if (!age.value || parseInt(age.value) < 16 || parseInt(age.value) > 80) {
            showFieldError(age, 'Please enter a valid age (16-80)');
            isValid = false;
        } else {
            clearFieldError(age);
        }

        if (!education.value) {
            showFieldError(education, 'Please select your education level');
            isValid = false;
        } else {
            clearFieldError(education);
        }
    }

    if (step === 2) {
        const job = document.getElementById('input-job');
        if (!job.value) {
            showFieldError(job, 'Please select a desired job role');
            isValid = false;
        } else {
            clearFieldError(job);
        }
    }

    return isValid;
}

function showFieldError(input, message) {
    input.classList.add('error');
    
    let errorEl = input.closest('.form-group')?.querySelector('.form-error');
    if (!errorEl) {
        errorEl = document.createElement('p');
        errorEl.className = 'form-error';
        input.closest('.input-wrapper')?.after(errorEl);
    }
    errorEl.textContent = message;
    errorEl.classList.add('show');

    // Remove error on focus
    input.addEventListener('focus', () => {
        clearFieldError(input);
    }, { once: true });
}

function clearFieldError(input) {
    input.classList.remove('error');
    const errorEl = input.closest('.form-group')?.querySelector('.form-error');
    if (errorEl) {
        errorEl.classList.remove('show');
    }
}

// ─── Submit Analysis ─────────────────────────────────────────────────
async function submitAnalysis() {

        const { data: { user } } = await supabaseClient.auth.getUser();

    if (!user) {
        showToast('Please sign in to continue.', 'error');
        window.location.assign('account.html');
        return;
    }

    if (!validateStep(2)) return;

    const formWrapper = document.getElementById('form-wrapper');
    const form = document.getElementById('analysis-form');
    const loading = document.getElementById('loading-state');
    const progressBar = document.getElementById('loader-bar');

    // Gather data
    const requestData = {
        name: document.getElementById('input-name').value.trim(),
        age: document.getElementById('input-age').value,
        education: document.getElementById('input-education').value,
        desiredJob: document.getElementById('input-job').value,
        currentSkills: document.getElementById('input-skills').value.trim()
    };

    const { error: profileError } = await supabaseClient.from('profiles').upsert({
        id: user.id,
        full_name: requestData.name,
        age: Number(requestData.age),
        education: requestData.education,
        updated_at: new Date().toISOString()
    });
    if (profileError) console.warn('Could not save personal details for next time:', profileError);

    // Show loading
    form.style.display = 'none';
    document.querySelector('.form-progress').style.display = 'none';
    loading.style.display = 'block';

    // Animate progress bar
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        progressBar.style.width = progress + '%';
    }, 200);

    try {
        const response = await fetch(`${API_BASE}/api/analyze`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });

        if (!response.ok) throw new Error('Analysis failed');

        analysisData = await response.json();

          const skills = parseSkillEntries(requestData.currentSkills);

          const { error: saveError } = await supabaseClient
              .from('analysis_results')
              .insert({
                  desired_job: analysisData.desiredJob,
                  education: requestData.education,
                  current_skills: skills,
                  matched_skills: analysisData.matchedSkills,
                  missing_skills: analysisData.missingSkills,
                  readiness_percent: analysisData.readinessPercent,
                  readiness_level: analysisData.readinessLevel
              });

          if (saveError) {
              console.error('Could not save analysis:', saveError);
              showToast('Analysis is ready, but could not be saved.', 'error');
          } else {
              showToast('Analysis saved to your account.', 'success');
          }
          

        // Complete progress bar
        clearInterval(progressInterval);
        progressBar.style.width = '100%';

        // Show results after a brief delay
        setTimeout(() => {
            loading.style.display = 'none';
            displayResults(analysisData);
        }, 600);

    } catch (error) {
        clearInterval(progressInterval);
        console.error('Analysis error:', error);
        
        loading.style.display = 'none';
        form.style.display = 'block';
        document.querySelector('.form-progress').style.display = 'flex';
        
        showToast('Unable to generate your analysis. Please try again.', 'error');
    }
}

// ─── Display Results ─────────────────────────────────────────────────
function displayResults(data) {
    const resultsSection = document.getElementById('results-section');
    const analyzeSection = document.getElementById('analyze');
    const analyzeNav = document.getElementById('nav-analyze');

    // Update progress to step 3
    currentStep = 3;
    updateProgress();

    // Hide form sections, show results
    analyzeSection.style.display = 'none';
    resultsSection.style.display = 'block';
    analyzeNav.textContent = 'Results';
    analyzeNav.href = '#results-section';
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    analyzeNav.classList.add('active');

    // Scroll to results
    resultsSection.scrollIntoView({ behavior: 'smooth' });

    // Populate subtitle
    document.getElementById('results-subtitle').textContent = 
        `Personalized analysis for ${data.name} — ${data.desiredJob}`;

    // ── Overview Cards ──
    // Readiness
    document.getElementById('readiness-score').textContent = data.readinessPercent + '%';
    document.getElementById('readiness-level').textContent = data.readinessLevel;
    
    // Animate radial progress
    const radialCircle = document.getElementById('radial-circle');
    const circumference = 2 * Math.PI * 42;
    const offset = circumference - (data.readinessPercent / 100) * circumference;
    setTimeout(() => {
        radialCircle.style.transition = 'stroke-dashoffset 1.5s cubic-bezier(0.16, 1, 0.3, 1)';
        radialCircle.style.strokeDashoffset = offset;
    }, 300);

    // Readiness badge color
    const badge = document.getElementById('readiness-level');
    if (data.readinessPercent >= 80) {
        badge.style.background = 'rgba(52, 211, 153, 0.15)';
        badge.style.color = '#34d399';
    } else if (data.readinessPercent >= 50) {
        badge.style.background = 'rgba(129, 140, 248, 0.15)';
        badge.style.color = '#818cf8';
    } else if (data.readinessPercent >= 25) {
        badge.style.background = 'rgba(251, 191, 36, 0.15)';
        badge.style.color = '#fbbf24';
    } else {
        badge.style.background = 'rgba(248, 113, 113, 0.15)';
        badge.style.color = '#f87171';
    }

    // Counts with animation
    animateNumber('matched-count', data.matchedSkillsCount, 800);
    animateNumber('missing-count', data.missingSkillsCount, 800);

    document.getElementById('matched-sub').textContent = 
        `of ${data.totalRequiredSkills} required`;
    document.getElementById('missing-sub').textContent = 
        `skills to acquire`;
    document.getElementById('learning-time').textContent = data.estimatedLearningTime;

    // ── Readiness Message ──
    document.getElementById('readiness-message').textContent = data.readinessMessage;

    // ── Career Info ──
    document.getElementById('salary-range').textContent = data.salaryRange;
    document.getElementById('rec-education').textContent = data.recommendedEducation;
    document.getElementById('job-category').textContent = data.category;

    // ── Skills Lists ──
    const matchedList = document.getElementById('matched-skills-list');
    const missingList = document.getElementById('missing-skills-list');

    matchedList.innerHTML = '';
    missingList.innerHTML = '';

    document.getElementById('matched-panel-count').textContent = data.matchedSkillsCount;
    document.getElementById('missing-panel-count').textContent = data.missingSkillsCount;

    if (data.matchedSkills.length === 0) {
        matchedList.innerHTML = '<p style="color: var(--text-muted); font-size: 0.85rem; padding: 8px 0;">No matched skills yet — start learning!</p>';
    } else {
        data.matchedSkills.forEach((skill, i) => {
            const item = document.createElement('div');
            item.className = 'skill-item matched';
            item.style.animationDelay = `${i * 0.05}s`;
            item.innerHTML = `
                <svg class="skill-icon" viewBox="0 0 18 18" fill="none">
                    <path d="M9 1.5C4.86 1.5 1.5 4.86 1.5 9s3.36 7.5 7.5 7.5 7.5-3.36 7.5-7.5S13.14 1.5 9 1.5zm-1.5 10.94L4.56 9.5l1.06-1.06 1.88 1.88 4.88-4.88 1.06 1.06-5.94 5.94z" fill="currentColor"/>
                </svg>
                ${escapeHtml(skill)}
            `;
            matchedList.appendChild(item);
        });
    }

    data.missingSkills.forEach((skill, i) => {
        const item = document.createElement('div');
        item.className = 'skill-item missing';
        item.style.animationDelay = `${i * 0.05}s`;
        item.innerHTML = `
            <svg class="skill-icon" viewBox="0 0 18 18" fill="none">
                <path d="M9 1.5C4.86 1.5 1.5 4.86 1.5 9s3.36 7.5 7.5 7.5 7.5-3.36 7.5-7.5S13.14 1.5 9 1.5zm3.75 10.19l-1.06 1.06L9 10.06 6.31 12.75 5.25 11.69 7.94 9 5.25 6.31 6.31 5.25 9 7.94l2.69-2.69 1.06 1.06L10.06 9l2.69 2.69z" fill="currentColor"/>
            </svg>
            ${escapeHtml(skill)}
        `;
        missingList.appendChild(item);
    });

    // ── Learning Resources ──
    const resourcesGrid = document.getElementById('resources-grid');
    resourcesGrid.innerHTML = '';

    if (data.learningResources.length === 0) {
        resourcesGrid.innerHTML = '<p class="section-desc">You already have all the required skills for this role.</p>';
    }

    data.learningResources.forEach((resource, i) => {
        const card = document.createElement('div');
        card.className = 'resource-card';
        card.style.animationDelay = `${i * 0.1}s`;

        const costClass = resource.cost.toLowerCase().includes('free') ? 'badge-free' : 'badge-paid';
        const skillCoverage = Array.isArray(resource.skills) && resource.skills.length
            ? `<p class="resource-skills">For: ${resource.skills.map(escapeHtml).join(', ')}</p>`
            : '';

        card.innerHTML = `
            <div class="resource-card-header">
                <h4>${escapeHtml(resource.title)}</h4>
            </div>
            ${skillCoverage}
            <div class="resource-badges">
                <span class="resource-badge ${costClass}">${escapeHtml(resource.cost)}</span>
                <span class="resource-badge badge-level">${escapeHtml(resource.level)}</span>
            </div>
            <a href="${escapeHtml(resource.url)}" target="_blank" rel="noopener noreferrer" class="resource-link">
                Visit Resource
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M4 10L10 4M10 4H5M10 4V9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
        `;
        resourcesGrid.appendChild(card);
    });
}

// ─── Reset Analysis ──────────────────────────────────────────────────
function resetAnalysis() {
    const resultsSection = document.getElementById('results-section');
    const analyzeSection = document.getElementById('analyze');
    const analyzeNav = document.getElementById('nav-analyze');
    const form = document.getElementById('analysis-form');
    const loading = document.getElementById('loading-state');
    const progressBar = document.getElementById('loader-bar');

    // Reset form
    document.getElementById('input-job').selectedIndex = 0;
    document.getElementById('input-skills').value = '';
    suggestedSkills = [];
    document.getElementById('skill-suggestions-panel').hidden = true;
    document.getElementById('skill-suggestions-list').replaceChildren();
    document.getElementById('skill-tags').innerHTML = '';
    document.getElementById('resume-file').value = '';
    document.getElementById('resume-status').textContent = 'Your resume file is not saved or uploaded.';
    resumeAddedSkills = [];

    // Reset progress
    progressBar.style.width = '0%';
    currentStep = 1;
    updateProgress();

    // Reset radial circle
    const radialCircle = document.getElementById('radial-circle');
    radialCircle.style.transition = 'none';
    radialCircle.style.strokeDashoffset = '264';

    // Show form, hide results
    resultsSection.style.display = 'none';
    analyzeSection.style.display = 'block';
    analyzeNav.textContent = 'Analyze';
    analyzeNav.href = '#analyze';
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    analyzeNav.classList.add('active');
    loading.style.display = 'none';
    form.style.display = 'block';
    document.querySelector('.form-progress').style.display = 'flex';

    // Reset steps
    document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
    document.getElementById('form-step-1').classList.add('active');

    // Scroll to analyze section
    analyzeSection.scrollIntoView({ behavior: 'smooth' });

    analysisData = null;
}

// ─── Scroll Animations ──────────────────────────────────────────────
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    const animatedElements = document.querySelectorAll(
        '.step-card, .form-card, .overview-card, .career-card, .breakdown-panel'
    );

    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1), transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
        observer.observe(el);
    });
}

// ─── Utility Functions ───────────────────────────────────────────────
function animateNumber(elementId, target, duration) {
    const element = document.getElementById(elementId);
    const start = 0;
    const startTime = performance.now();

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = Math.round(start + (target - start) * easeOut);
        element.textContent = current;

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'info') {
    // Remove existing toasts
    document.querySelectorAll('.toast').forEach(t => t.remove());

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            ${type === 'error' 
                ? '<circle cx="9" cy="9" r="8" stroke="#f87171" stroke-width="1.5" fill="none"/><path d="M9 5.5v4M9 12.5h.01" stroke="#f87171" stroke-width="1.5" stroke-linecap="round"/>'
                : '<circle cx="9" cy="9" r="8" stroke="#34d399" stroke-width="1.5" fill="none"/><path d="M6 9l2 2 4-4" stroke="#34d399" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'}
        </svg>
        ${escapeHtml(message)}
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

