@echo off
setlocal

echo ============================================
echo   SkillBridge - Skill Gap Analyser
echo   Building and Starting Server...
echo ============================================
echo.

:: Move to the project root (the folder containing run.bat)
cd /d "%~dp0"

:: Check for .env
if not exist ".env" (
    echo [ERROR] .env file not found beside run.bat.
    pause
    exit /b 1
)

:: Load the Gemini key from .env
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
    if /i "%%A"=="GEMINI_API_KEY" set "GEMINI_API_KEY=%%B"
)

if not defined GEMINI_API_KEY (
    echo [ERROR] GEMINI_API_KEY was not found in .env.
    pause
    exit /b 1
)

:: Create the build folder if needed
if not exist "build" mkdir build

:: Compile the Java files
echo [1/2] Compiling Java source files...
javac -encoding UTF-8 -d build backend\backend\src\main\java\com\skillgap\SkillGapServer.java backend\backend\src\main\java\com\skillgap\SkillGapAnalyzer.java

if errorlevel 1 (
    echo.
    echo [ERROR] Compilation failed. Check the file paths and that the JDK is installed.
    pause
    exit /b 1
)

:: Start the server
echo.
echo [2/2] Starting server...
echo Open http://localhost:8080 in your browser.
echo Keep this window open while using the site.
echo.

java -cp build com.skillgap.SkillGapServer

pause